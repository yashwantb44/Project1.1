package com.app.pojos;

public enum UserType {

	ADMIN,CUSTOMER,DISTRIBUTOR;
}
