package com.app.pojos;

public enum CylinderType {
	COMMERCIAL,DOMESTIC;

}
