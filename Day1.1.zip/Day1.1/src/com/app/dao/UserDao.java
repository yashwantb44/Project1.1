package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Customer;
import com.app.pojos.Distributor;
import com.app.pojos.User;

@Repository
@Transactional
public class UserDao implements IUserDao 
{
	@Autowired
	private SessionFactory sf;
	@Override
	public User validateUser(String email, String password) 
	{
		String jpql = "select u from User u where u.userEmail=:em and u.userPassword=:pass";
		return sf.getCurrentSession().createQuery(jpql, User.class).setParameter("em", email).setParameter("pass", password).getSingleResult();
	}
	@Override
	public String addUser(User user, Distributor distributor) 
	{
		sf.getCurrentSession().persist(user);
		sf.getCurrentSession().persist(distributor);
		return "User registered successfully..";
	}
	@Override
	public String registerCustomer(User user, Customer customer) 
	{
		String jpql = "select d from Distributor d where d.pin=:pin";
		Distributor distributor = sf.getCurrentSession().createQuery(jpql, Distributor.class).setParameter("pin", customer.getPin()).getSingleResult();
		distributor.addCustomer(customer);
		sf.getCurrentSession().persist(distributor);
		sf.getCurrentSession().persist(user);
		return "Customer added successfully..";
	}
}
