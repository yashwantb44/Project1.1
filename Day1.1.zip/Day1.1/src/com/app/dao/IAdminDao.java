package com.app.dao;

import java.util.List;

import com.app.pojos.Distributor;

public interface IAdminDao 
{
	List<Distributor> getAllDistributors();
}
