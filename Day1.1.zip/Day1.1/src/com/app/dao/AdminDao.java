package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Distributor;

@Repository
@Transactional
public class AdminDao implements IAdminDao 
{
	@Autowired
	private SessionFactory sf;
	@Override
	public List<Distributor> getAllDistributors() 
	{
		String jpql = "select d from Distributor d";
		return sf.getCurrentSession().createQuery(jpql, Distributor.class).getResultList();
	}
}
