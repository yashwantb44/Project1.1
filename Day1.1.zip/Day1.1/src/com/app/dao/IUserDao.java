package com.app.dao;

import com.app.pojos.Customer;
import com.app.pojos.Distributor;
import com.app.pojos.User;

public interface IUserDao 
{
	User validateUser(String email,String password);
	String addUser(User user, Distributor distributor);
	String registerCustomer(User user, Customer customer);
}
