package com.app.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.dao.IDistributorDao;

@Controller
@RequestMapping("/distributer")
public class DistributorController 
{
	@Autowired
	private IDistributorDao dao;
	
	@GetMapping("/display")
	public String getCustomers(HttpSession hs)
	{
		hs.setAttribute("cust_list", dao.getCustomers());
		return "/distributor/display";
	}
}
