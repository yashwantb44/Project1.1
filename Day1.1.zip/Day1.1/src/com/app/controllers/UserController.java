package com.app.controllers;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.IUserDao;
import com.app.pojos.Address;
import com.app.pojos.Customer;
import com.app.pojos.CylinderType;
import com.app.pojos.Distributor;
import com.app.pojos.User;
import com.app.pojos.UserType;

@Controller
@RequestMapping("/user")
public class UserController 
{
	@Autowired
	private IUserDao dao;
	@PostMapping("/login")
	public String login(@RequestParam String email, @RequestParam String password,HttpSession hs)
	{
		try
		{
			User user = dao.validateUser(email, password);
			hs.setAttribute("user_details", user);
			if(user.getUserType().equals(UserType.valueOf("ADMIN")))
			{
				return "redirect:/admin/display";
			}
			else if(user.getUserType().equals(UserType.valueOf("CUSTOMER")))
			{
				return "/customer/display";
			}
			else
			{
				return "redirect:/distributer/display";
			}
		}
		catch(RuntimeException ex)
		{
			ex.printStackTrace();
			return "/user/login";
		}
	}
	@GetMapping("/register1")
	public String registerCustomer()
	{
		return "/user/register1";
	}
	
	@PostMapping("/register1")
	public String registerCustomer(@RequestParam String name,
			@RequestParam String email,
			@RequestParam String password,
			@RequestParam String phone,
			@RequestParam String area,
			@RequestParam String city,
			@RequestParam String dist,
			@RequestParam int pin,
			@RequestParam String aadhar,
			@RequestParam byte[] img,
			@RequestParam String ct)
	{
		User user = new User(name, email, password, new Date(), phone, UserType.valueOf("CUSTOMER"));
		Customer customer = new Customer(name, aadhar,pin, img, CylinderType.valueOf(ct));
		user.addAddress(new Address(area, city, dist, pin));
		dao.registerCustomer(user,customer);
		return null;
	}
	@GetMapping("/register2")
	public String registerDistributor()
	{
		return "/user/register2";
	}
	
	@PostMapping("/register2")
	public String registerDistributor(@RequestParam String name,
			@RequestParam String email,
			@RequestParam String password,
			@RequestParam String phone,
			@RequestParam String area,
			@RequestParam String city,
			@RequestParam String dist,
			@RequestParam int pin,
			@RequestParam int cs,
			@RequestParam int ds)
	{
		Address addr = new Address(area, city, dist, pin);
		User user = new User(name, email, password, new Date(), phone, UserType.valueOf("DISTRIBUTOR"));
		user.addAddress(addr);
		Distributor distributor = new Distributor(name,pin, cs, ds);
		System.out.println(dao.addUser(user,distributor));
		return null;
	}
	
}
