package com.app.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.pojos.User;

@Controller
@RequestMapping("/customer")
public class CustomerController 
{
	@GetMapping("/book")
	public String bookCylinder(HttpSession hs)
	{
		User user = (User)hs.getAttribute("user_details");

		return "/customer/book";
	}
}
